def pb1():
    """
    Uses Bayes' rule to derive the posterior position of a rover, given a
    GPS measurement, and plots the 95% CI for both the prior and posterior.
    """
    # define constants
    mu_x = np.zeros((2,1))
    mu_y = np.zeros((2,1))
    
    Sigma_xx = np.array([[0.7, 0.73],[0.73, 1.1]])
    Sigma_xy = np.array([[0.63, 0.23],[0.72, 0.31]])
    Sigma_yy = np.array([[0.7, 0.19],[0.19, 0.16]])
    
    y = np.array([[0.27],[0.62]])
    
    # Compute parameters of the posterior (conditional) distribution.
    mu_post = mu_x + Sigma_xy @ np.linalg.inv(Sigma_yy) @ (y - mu_y)
    Sigma_post = Sigma_xx - Sigma_xy @ np.linalg.inv(Sigma_yy) @ Sigma_xy.T

    print("mu_x|y: ", mu_post)
    print("Sigma_x|y: ", Sigma_post)

    # Plot prior/posterior CIs.
    plot_ellipse(0.95, mu_x, Sigma_xx, label="prior")
    plot_ellipse(0.95, mu_post, Sigma_post, label="posterior", color="C2")

    # Scatter the posterior mean, and the noisy GPS measurement.
    plt.scatter(mu_post[0,:], mu_post[1,:], c="C1", label="mu_x|y")
    plt.scatter(y[0,:], y[1, :], c="C3", label="y")
    plt.legend()
    plt.axis("equal")
    plt.title("Prior and Posterior Confidence Ellipses, Problem 5")