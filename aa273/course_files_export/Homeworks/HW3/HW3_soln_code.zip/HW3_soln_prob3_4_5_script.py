# %%
import numpy as np
import matplotlib.pyplot as plt
import HW3_soln_prob3_4_5_sim_class as sim
from scipy.linalg import sqrtm

class KalmanFilter:
    def __init__(self, A, B, C, mu0, sigma0, 
                 q_mat= np.identity(4), 
                 r_mat = np.identity(2)) -> None:
        
        # Check that the matrices are square and positive definite.
        assert q_mat.shape[0] == q_mat.shape[1], "Q matrix must be square"
        assert r_mat.shape[0] == r_mat.shape[1], "R matrix must be square"
        assert np.all(np.linalg.eigvals(q_mat) > 0), \
            "Q matrix must be positive definite"
        assert np.all(np.linalg.eigvals(r_mat) > 0), \
            "R matrix must be positive definite"
        self.A = A
        self.B = B
        self.C = C
        self.q_mat = q_mat
        self.r_mat = r_mat
        self.mu = mu0
        self.sigma = sigma0
        pass

    def predict(self, u):
        self.mu_predict = self.A @ self.mu + self.B @ u
        self.sigma_predict = self.A @ self.sigma @ self.A.T + self.q_mat

        return self.mu_predict, self.sigma_predict
    
    def update(self, y):
        K = self.sigma_predict @ self.C.T @ np.linalg.inv(self.C @ self.sigma_predict @ self.C.T + self.r_mat)
        self.mu = self.mu_predict + K @ (y - self.C @ self.mu_predict)
        self.sigma = self.sigma_predict - K @ self.C @ self.sigma_predict
        return self.mu, self.sigma


# Calculates the standard gaussian circle
P = 0.95
theta = np.linspace(0, 2*np.pi, 50)
r = np.sqrt(-2*np.log(1 - P))
w1 = r*np.cos(theta)
w2 = r*np.sin(theta)

def ellipse_points(mu, cov):
    theta_len = len(theta)
    w = np.zeros((theta_len, 2, 1))
    x = np.zeros((theta_len, 2, 1))
    for i in range(theta_len):
        w[i] = np.array([[w1[i]], [w2[i]]])
        x[i] = sqrtm(cov) @ w[i] + mu.reshape((2,1))
    return x

def plot_mean_and_cov_traj(mean_vals,
                    cov_vals,
                    true_vals,
                    title="Kalman Filter Position Values",
                    x_label="KF Position Values in X (m)",
                    y_label="KF Position Values in y (m)",
                    measurement_size=10, show_plot=True):
    
    # Plot the means
    n = mean_vals.shape[0]
    fig, ax = plt.subplots(figsize=(8, 6))
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)

    # Plot the covariances
    for i in range(n):
        ellipse = ellipse_points(mean_vals[i, :], cov_vals[i,:,:])
        if i == 0:
            plt.plot(ellipse[:,0, 0], ellipse[:,1, 0], 'b--', linewidth=2, label='Position covariance')
        else:
            plt.plot(ellipse[:,0, 0], ellipse[:,1, 0], 'b--', linewidth=2)
    
    # Plot the means
    plt.scatter(mean_vals[:, 0], mean_vals[:, 1],
                s=measurement_size, marker='o', color='g', label='Estimated Position')
    
    plt.plot(true_vals[:, 0], true_vals[:, 1], color='k', label='True trajectory')
    
    plt.legend()
    plt.grid(True)
    plt.axis('equal')
    plt.tight_layout()

    if show_plot:
        plt.show()
    return fig


def plot_mean_and_cov_traj_with_vel(mean_vals,
                            vel_means,
                            vel_covs,
                            title="Kalman Filter Position and Velocity",
                            x_label="Position X (m)",
                            y_label="Position Y (m)",
                            measurement_size=10,
                            show_plot=True):
    n = mean_vals.shape[0]
    fig, ax = plt.subplots(figsize=(10, 8))
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)

    # Plot position means
    plt.scatter(mean_vals[:, 0], mean_vals[:, 1],
                s=measurement_size, marker='o', color='g', label='Estimated Position')

    scale = 3.0
    # Plot velocity vectors and their covariances
    for i in range(n):
        start_point = mean_vals[i, :]
        velocity = vel_means[i, :]

        # Draw velocity vector
        if i == 0:
            plt.arrow(start_point[0], start_point[1],
                  scale*velocity[0], scale*velocity[1],
                  head_width=0.2, head_length=0.3, fc='r', ec='r', label='Estimated velocity vector (x3 scale)')
        else:
            plt.arrow(start_point[0], start_point[1],
                  scale*velocity[0], scale*velocity[1],
                  head_width=0.2, head_length=0.3, fc='r', ec='r')

        # Compute ellipse at the tip of the velocity vector
        vel_tip = start_point + scale*velocity
        vel_ellipse = ellipse_points(vel_tip, vel_covs[i,:,:])
        if i == 0:
            plt.plot(vel_ellipse[:,0,0], vel_ellipse[:,1,0], 'b--', linewidth=1.5, label='Velocity Covariance')
        else:
            plt.plot(vel_ellipse[:,0,0], vel_ellipse[:,1,0], 'b--', linewidth=1.5)

    plt.legend()
    plt.grid(True)
    plt.axis('equal')
    plt.tight_layout()

    if show_plot:
        plt.show()
    return fig
    
# Define simulation parameters
n_steps = 100
p0 = [1000, 0]
s0 = [0, 50]

# %% Question 3

# Initialize the simulator
# Arguments:
# sensor: str - "GPS" for Question 1, "Velocity" for Question 2
# q_mat: np.array - process noise covariance matrix
# r_mat: np.array - measurement noise covariance matrix
# dt: float - time step
# rng_seed: int - for reproducibility
Q = np.eye(2)
R = 9*np.eye(2)
quadrotor = sim.QuadrotorSimulator(sensor="GPS", q_mat=Q, r_mat=R)

# Do a single run
p0 = np.array([1000.0, 0.0]).T
s0 = np.array([0.0, 50.0]).T
phist, shist, yhist, uhist = quadrotor.simulate(p0, s0, n_steps)

# %% Running multiple simulations
# We have several plotting functions to visualize the results:
# 1. quadrotor.plot_position_histories(...) - plots the 2D position across runs
# 2. quadrotor.plot_velocity_histories(...) - plots the 2D velocity across runs

n_runs = 5
phist_many, shist_many, yhist_many, uhist_many = quadrotor.simulate_multiple_runs(p0, s0, n_steps, n_runs)
fig1 = quadrotor.plot_position_histories(phist_many, all_measurements=yhist_many,measurement_size= 5, show_plot=True)
fig1.savefig('./Q3_trajectory_rollouts.png')


# %% Interfacing with your Kalman Filter implementation

# You will use the simulator to generate data to test your Kalman Filter 
# implementation. There are two ways to do this:
# 1. [Recommended] Run the _whole_ simulation in the simulator and pass the
#    generated measurements to your Kalman Filter implementation one-by-one.
#    This works since we are _not_ using active control (akin to using data 
#    from a previously collected dataset). It will make sure that the 
#    measurements you are using are consistent with the simulator ground
#    truth, and that the ground truth state does not end up in your filter.
# 2. Run the simulator and Kalman Filter in lockstep. This is more realistic
#    but can be harder to debug. 

# If you are using the first method, you can use the simulator as described
# above. 
# i.e., use quadrotor.simulate(...) to generate the data, and then loop through
# the measurements to pass them to your Kalman Filter implementation.

# %% Question 4
dt = 1.0

# State space matrices based on Q3a
A = np.array([[1.0, 0.0, dt, 0.0], 
              [0.0, 1.0, 0.0, dt],
              [0.0, 0.0, 1.0, 0.0],
              [0.0, 0.0, 0.0, 1.0]])
B = np.array([[0.0, 0.0],
              [0.0, 0.0],
              [dt, 0.0],
              [0.0, dt]])
C = np.array([[1.0, 0.0, 0.0, 0.0],
              [0.0, 1.0, 0.0, 0.0]])
mu0 = np.array([1500.0, 100.0, 0.0, 55.0]).T
sigma0 = np.hstack((np.vstack((250000.0*np.eye(2), np.zeros((2,2)))), np.vstack((np.zeros((2,2)), np.eye(2)))))
Q = np.diag([1e-10, 1e-10, 1.0, 1.0])
R = 9.0 * np.eye(2)
kalman_filter = KalmanFilter(A, B, C, mu0 ,sigma0, q_mat=Q, r_mat=R)
state_vals = np.zeros((n_steps+1, 4))
cov_vals = np.zeros((n_steps+1, 4, 4))
state_vals[0, :] = mu0
cov_vals[0, :, :] = sigma0

for t_index, (u, y) in enumerate(zip(uhist, yhist)):
    # Use (u, y) to step your Kalman Filter
    state_predict, cov_predict = kalman_filter.predict(u)
    state_vals[t_index+1, :], cov_vals[t_index+1, :, :] = kalman_filter.update(y)
    pass

pos_means = state_vals[:, 0:2]
vel_means = state_vals[:, 2:4]
pos_covs = cov_vals[:, 0:2, 0:2]
vel_covs = cov_vals[:, 2:4, 2:4]


# %% Plotting KF quantities
fig1 = plot_mean_and_cov_traj(pos_means, pos_covs, phist, show_plot=True)
fig1.savefig('./Q4_position_with_KF.png')
fig2 = plot_mean_and_cov_traj_with_vel(pos_means, vel_means, vel_covs, title='Kalman Filter with Velocity Vectors', x_label='KF Position Values in X (m)', y_label='KF Position Values in Y (m)', show_plot=True)
fig2.savefig('./Q4_velocity_with_KF.png')

# %% Question 5

# Initialize the simulator and single traj
quadrotor = sim.QuadrotorSimulator(sensor="Velocity")

# You can use the same functions as above to run and visualize the simulation.

p0 = np.array([1000.0, 0.0]).T
s0 = np.array([0.0, 50.0]).T
phist, shist, yhist, uhist = quadrotor.simulate(p0, s0, n_steps)

# %% Kalman Filter with Velocity Sensor
dt = 1.0
A = np.array([[1.0, 0.0, dt, 0.0], 
              [0.0, 1.0, 0.0, dt],
              [0.0, 0.0, 1.0, 0.0],
              [0.0, 0.0, 0.0, 1.0]])
B = np.array([[0.0, 0.0],
              [0.0, 0.0],
              [dt, 0.0],
              [0.0, dt]])
C = np.array([[0.0, 0.0, 1.0, 0.0],
              [0.0, 0.0, 0.0, 1.0]])
mu0 = np.array([1000.0, 0.0, 0.0, 50.0]).T
sigma0 = np.hstack((np.vstack((1.0*np.eye(2), np.zeros((2,2)))), np.vstack((np.zeros((2,2)), np.eye(2)))))
Q = np.diag([1e-10, 1e-10, 1.0, 1.0])
R = 9.0 * np.eye(2)
kalman_filter = KalmanFilter(A, B, C, mu0 ,sigma0, q_mat=Q, r_mat=R)
state_vals = np.zeros((n_steps+1, 4))
cov_vals = np.zeros((n_steps+1, 4, 4))
state_vals[0, :] = mu0
cov_vals[0, :, :] = sigma0

for t_index, (u, y) in enumerate(zip(uhist, yhist)):
    # Use (u, y) to step your Kalman Filter
    state_predict, cov_predict = kalman_filter.predict(u)
    state_vals[t_index+1, :], cov_vals[t_index+1, :, :] = kalman_filter.update(y)
    pass

pos_means = state_vals[:, 0:2]
vel_means = state_vals[:, 2:4]
pos_covs = cov_vals[:, 0:2, 0:2]
vel_covs = cov_vals[:, 2:4, 2:4]

# %% Plotting KF quantities
fig1 = plot_mean_and_cov_traj(pos_means, pos_covs, phist, show_plot=True)
fig1.savefig('./Q5_position_with_KF.png')
fig2 = plot_mean_and_cov_traj_with_vel(pos_means, vel_means, vel_covs, title='Kalman Filter Velocity Vectors', x_label='KF Position Values in X (m)', y_label='KF Position Values in Y (m)', show_plot=True)
fig2.savefig('./Q5_velocity_with_KF.png')