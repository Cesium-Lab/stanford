
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import scipy.stats

def solve_ellipse_eigen(sigma_inv):
    """
    Solve the eigenvalues and eigenvectors. Return in order of highest to lowest
    :param sigma_inv: The inverse of the covariance matrix
    :return: the eigenvalues and eigenvectors
    """
    eig_vals, eig_vectors = np.linalg.eig(sigma_inv)
    idx = eig_vals.argsort()[::-1]
    eig_vals = eig_vals[idx]
    eig_vectors = eig_vectors[:, idx]

    return eig_vals, eig_vectors


def solve_ellipse_params(eig_vals, eig_vectors, prob_conf):
    """
    Calculate the semi-major axis, semi-minor axis, and rotation angle from the eigen decomposition of the inverse of
    the covariance matrix
    :param eig_vals: The eigenvalues of the inverse of the covariance matrix
    :param eig_vectors: The eigenvectors of the inverse of the covariance matrix
    :param prob_conf: The probability for this confidence ellipse
    :return: semi-major axis (a), semi-minor axis (b), angle (theta)
    """

    # Numerator for semi axes
    prob_param = -2 * np.log(1 - prob_conf)
    # Assert that the above is positive to have real valued axes
    assert prob_param > 0
    # Calculate the axes
    b_semi_minor, a_semi_major = np.sqrt(prob_param / eig_vals)
    # Calculate the angle
    x_hat = np.array([1, 0])
    if eig_vectors[:, 1].shape[0] == 2:
        theta = np.arctan2(eig_vectors[1, 1], eig_vectors[0, 1])
    else:
        theta = np.arccos(x_hat @ eig_vectors[:, 1])

    return a_semi_major, b_semi_minor, theta

def plot_ellipse_updated(mu, sigma, p_conf, color, ax, lw=2):
    """
    Change the plotting function from HW 2 to work with this HW
    :param mu: The mean
    :param sigma: The covariance matrix
    :param p_conf: The probability
    :param color: The ellipse color
    :param ax: The axes
    :param lw: The line width
    :return: None
    """
    # print(sigma)
    sigma_inv = np.linalg.inv(sigma)
    eig_lambda, eig_vec = solve_ellipse_eigen(sigma_inv)
    a, b, t = solve_ellipse_params(eig_lambda, eig_vec, p_conf)

    # Make the ellipse
    ellipse = matplotlib.patches.Ellipse(
        xy=mu, width=2 * a, height=2 * b, angle=np.rad2deg(t),
        facecolor=(*color, 0.2), edgecolor=(*color, 1),
        linewidth=lw, zorder=2)

    # Plot the ellipse
    ax.add_patch(ellipse)

    return ellipse

def plot_filter_trajectory(mu, sigma, p_conf, color, ax, filter_name):
    """
    Plot the trajectory of a filter
    :param mu: The mean
    :param sigma: The covariance matrix
    :param p_conf: The probability
    :param color: The ellipse color
    :param ax: The axes
    :return: None
    """
    # Plot the ellipse
    for mu_t, sigma_t in zip(mu[:, :2], sigma[:, :2, :2]):
        plot_ellipse_updated(mu_t, sigma_t, p_conf, color, ax,
                             lw=0.5)

    # Plot the trajectory
    # ax.plot(mu[:, 0], mu[:, 1], color=color, marker='x',
    #         linestyle='--', markersize=5, zorder=3,
    #         label=f'{filter_name} Estimate')

    theta_offset = -90  # Offset for the triangle marker
    labeled = False
    label_txt = f'{filter_name} Estimate ({int(p_conf * 100)}% Conf. Ellipse)'

    for mu_t in mu:
        px, py, theta = mu_t


        label_curr = label_txt if not labeled else None
        plt.scatter(px, py,
                    edgecolors='green', facecolors='none',
                    s=50, zorder=2,
                    marker=(3, 0, theta_offset + np.rad2deg(theta)),
                    label=label_curr)
        labeled = True


def plot_1D_confidence_interval(mu, sigma, p_conf, color, ax):
    """
    Plot the 1D confidence interval
    :param mu: The mean
    :param sigma: The covariance matrix
    :param p_conf: The probability
    :param color: The ellipse color
    :param ax: The axes
    :return: None
    """
    # Get z-score for the (centered) confidence interval
    # scipy will give the z-score for the lower tail, so we need to
    # split the difference such that (1 - p_conf)/2 is in each tail.
    # 1 - (1 - p_conf)/2 = 1/2 + p_conf/2
    p_query = 1/2 + p_conf/2
    z_score = scipy.stats.norm.ppf(p_query)
    print(f"Z-Score: {z_score} at {p_conf} confidence")

    # Plot the 1D confidence interval
    std_t = np.sqrt(sigma)
    covar_above = mu + z_score * std_t
    covar_below = mu - z_score * std_t
    t_stamps = np.arange(len(mu))
    ax.fill_between(t_stamps, covar_below, covar_above,
                        color=color, alpha=0.2, zorder=2)

    # Plot the mean
    ax.plot(t_stamps, mu, color=color, linestyle='--', zorder=3)


def plot_filter_time_history(true_pose, filter_pose, filter_sigma,
                                   p_conf, filter_name, is_error=False):
    """
    Plot the trajectory of a filter as a function of time
    :param true_pose: The true pose
    :param filter_pose: The filter pose
    :param filter_sigma: The filter sigma
    :param p_conf: The probability
    :param filter_name: The filter name
    :param is_error: Plot is of the error
    :return: None
    """
    fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(15, 5))

    # Plot each component
    labels = ['X Position', 'Y Position', 'Theta Heading']
    ylabels = ['X Position (m)', 'Y Position (m)', 'Theta Heading (rad)']

    if is_error:
        labels = [f'Error in {label}' for label in labels]
        ylabels = [f'Error in {label}' for label in ylabels]

    for ax_idx, (ax, label, ylab) in enumerate(zip(axes, labels, ylabels)):
        ax.plot(true_pose[:, ax_idx], color='b')
        plot_1D_confidence_interval(
            filter_pose[:, ax_idx], filter_sigma[:, ax_idx, ax_idx],
            p_conf, 'g', ax)
        ax.set_title(label)
        leg = ax.legend(['True',
                   f'{filter_name} {int(p_conf*100)}% CI',
                   f'{filter_name} Estimate'])
        leg.get_frame().set_alpha(1)
        ax.set_xlabel('Time Step')
        ax.set_ylabel(ylab)

        # If we are plotting the angle, include the angle bounds of [-pi, pi]
        if ax_idx == 2:
            ax.axhline(y=-np.pi, color='gray', linestyle='--', zorder=1)
            ax.axhline(y=np.pi, color='gray', linestyle='--', zorder=1)
        
    plt.tight_layout()

    return fig, axes

############
# Particle Filter Specific
# (Plot all particles)

def plot_particle_filter_trajectory(particles, color, ax, filter_name):
    """
    Plot the trajectory of a particle filter
    :param particles: The particles
    :param color: The ellipse color
    :param ax: The axes
    :return: None
    """
    # Plot the trajectory
    all_x = particles[:, 0, :].flatten()
    all_y = particles[:, 1, :].flatten()
    ax.scatter(all_x, all_y, color=color, marker='.',
               s=5, zorder=3, alpha=0.01, edgecolors=None)#,
            #    label=f'{filter_name} Estimate')
    
    # plot one point without alpha for legend
    ax.scatter(all_x[0], all_y[0], color=color, marker='.',
               s=5, zorder=0, edgecolors=None, alpha=0.5,
               label=f'{filter_name} Estimate')


def plot_particle_filter_distribution_history(true_pose, filter_pose_particles, 
                                            filter_name, plot_type='violin',
                                            is_error=False):
    """
    Plot the distribution of a particle filter as a function of time
    :param true_pose: The true pose
    :param filter_pose_particles: The filter pose as particles
    :param filter_name: The filter name
    :param plot_type: The type of plot to use
    :param is_error: Plot is of the error
    :return: None
    """
    
    n_time_steps, n_states, _ = filter_pose_particles.shape
    time_arr = np.arange(n_time_steps)

    # Make wide plots since we want to show the distribution of particles
    fig_base_size = 10
    fig, axes = plt.subplots(nrows=n_states, ncols=1, 
                             figsize=(fig_base_size, fig_base_size))

    # Plot the each
    labels = ['X Position', 'Y Position', 'Theta Heading']
    ylabels = ['X Position (m)', 'Y Position (m)', 'Theta Heading (rad)']

    if is_error:
        labels = [f'Error in {label}' for label in labels]
        ylabels = [f'Error in {label}' for label in ylabels]

    for ax_idx, (ax, label) in enumerate(zip(axes, labels)):
        ax.plot(true_pose[:, ax_idx], color='b')
        if plot_type == 'violin':
            violins = ax.violinplot(filter_pose_particles[:, ax_idx, :].T, 
                          positions=time_arr,
                          showmeans=False, showmedians=True)
            # Change the color of the violin bodies
            for pc in violins['bodies']:
                pc.set_facecolor('g')
                pc.set_alpha(0.85)
                pc.set_edgecolor('k')
                pc.set_linewidth(0.5)
            # Change the color of the violin lines
            violin_lines = ['cmaxes', 'cmins', 'cbars', 'cmedians']
            for lines in violin_lines:
                violins[lines].set_color('k')
                violins[lines].set_alpha(1)
                violins[lines].set_linewidth(0.5)
            
        elif plot_type == 'scatter':
            # Augment the time array to match the shape of the particles
            time_arr_aug = np.tile(time_arr, 
                                   (filter_pose_particles.shape[2], 1)).T
            ax.scatter(time_arr_aug, filter_pose_particles[:, ax_idx, :],
                       marker='_', color='g', s=5, alpha=0.01)
            
        elif plot_type == 'boxplot':
            ax.boxplot(filter_pose_particles[:, ax_idx, :].T,
                       positions=time_arr,
                       manage_ticks=False, patch_artist=True,
                       boxprops=dict(facecolor='g', alpha=0.5),
                       whiskerprops=dict(color='k', linewidth=0.5),
                       capprops=dict(color='k', linewidth=0.5),
                       medianprops=dict(color='k', linewidth=0.5),
                       flierprops=dict(marker='.', markersize=1, color='k'))


        else:
            raise ValueError(f"Unknown plot type: {plot_type}")
        
        ax.set_title(label)
        leg = ax.legend(['True', f'{filter_name} Estimate'])
        leg.get_frame().set_alpha(1)
        ax.set_xlabel('Time Step')
        ax.set_ylabel(ylabels[ax_idx])

        # If we are plotting the angle, include the angle bounds of [-pi, pi]
        if ax_idx == 2:
            ax.axhline(y=-np.pi, color='gray', linestyle='--', zorder=1)
            ax.axhline(y=np.pi, color='gray', linestyle='--', zorder=1)
        
    plt.tight_layout()
    return fig, axes
