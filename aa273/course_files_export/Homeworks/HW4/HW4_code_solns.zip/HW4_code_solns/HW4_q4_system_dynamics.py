###########################
# Simulate a (nonlinear) dyanmical system
###########################

import numpy as np


class DynamicSystem():
    """
    Base class for the (nonlinear) Dynamic System.

    System is assumed to be differentiable with analytical Jacobians.
    """
    def __init__(self, q_mat, r_mat):
        """
        Initialize the system matrices
        """
        self.q_mat = np.array(q_mat)
        self.r_mat = np.array(r_mat)
        self.r_mat_inv = np.linalg.inv(self.r_mat)

    def f_func(self, mu, u):
        """
        State Transition Function
        """
        raise NotImplementedError

    def f_jac(self, mu, u):
        """
        Jacobian of the State Transition Function
        """
        raise NotImplementedError

    def g_func(self, mu):
        """
        Measurement Function
        """
        raise NotImplementedError

    def g_jac(self, mu):
        """
        Jacobian of the Measurement Function
        """
        raise NotImplementedError

    def sample_f(self, mu, u, n_samples=1):
        """
        Sample the State Transition Model (i.e., with process noise)
        """
        raise NotImplementedError

    # def sample_g(self, mu, n_samples=1):
    #     """
    #     Sample the Measurement Model (i.e., with measurement noise)
    #     """
    #     raise NotImplementedError

    def observability(self, mu, u):
        """
        Calculate the Observability Matrix
        """
        n = mu.shape[0]

        # Initialize the observability matrix
        obs_mat = [self.g_jac(mu)]
        for _ in range(1, n):
            obs_mat.append(np.dot(obs_mat[-1], self.f_jac(mu, u)))

        obs_mat = np.vstack(obs_mat)

        assert obs_mat.shape == (n * self.g_jac(mu).shape[0], n)

        return obs_mat

    def observability_svd_vals(self, mu, u):
        """
        Calculate the Singular Values of the Observability Matrix
        """
        obs_mat = self.observability(mu, u)
        svd_vals = np.linalg.svd(obs_mat, compute_uv=False)

        assert svd_vals.shape == (mu.shape[0],)

        return svd_vals


class MobileRobot(DynamicSystem):
    """
    Child class for the Mobile Robot
    """
    def __init__(self, q_mat, r_mat, dt, base_station_locs):
        """
        Initialize the EKF with the system matrices
        """
        super().__init__(q_mat, r_mat)

        self.dt = dt
        self.base_station_locs = np.array(base_station_locs)
        self.num_stations = base_station_locs.shape[0]

    def f_func(self, mu, u):
        """
        State Transition Function
        """
        px, py, theta = mu
        s, phi = u

        px_new = px + self.dt * s * np.cos(theta)
        py_new = py + self.dt * s * np.sin(theta)
        theta_new = theta + self.dt * phi

        return np.array([px_new, py_new, theta_new])

    def f_jac(self, mu, u):
        """
        Jacobian of the State Transition Function
        """
        _, _, theta = mu
        s, _ = u

        return np.array([
            [1, 0, -self.dt * s * np.sin(theta)],
            [0, 1, self.dt * s * np.cos(theta)],
            [0, 0, 1]
        ])

    def g_func(self, mu):
        """
        Measurement Function.

        Needs to be vectorized since mu can have multiple state instances to
        pass through in parallel.
        """
        # For EKF, mu is a 1D array of shape (3,)
        # For UKF or PF, mu is a 2D array of shape (3, n_samples)

        # The position is always the first two elements of mu
        # (2,) or (2, n_samples)
        pos = mu[:2]

        # The base stations are stored in a 2D array of shape (num_stations, 2)
        # We will have a total of `num_stations` measurements
        # (num_stations,) or (num_stations, n_samples)
        if pos.ndim == 1:
            # EKF case
            y_meas = np.linalg.norm(self.base_station_locs - pos, axis=1)
            assert y_meas.shape == (self.num_stations,)
        else:
            # UKF or PF case
            y_meas = np.linalg.norm(
                self.base_station_locs[:, :, np.newaxis] - pos[np.newaxis, :, :], axis=1)
            assert y_meas.shape == (self.num_stations, pos.shape[1])

            # Non vectorized option
            # n_samples = pos.shape[1]
            # y_meas = np.zeros((self.num_stations, n_samples))
            # for b_ind in range(self.base_station_locs.shape[0]):
            #     for s_ind in range(n_samples):
            #         y_meas[b_ind, s_ind] = np.linalg.norm(
            #             self.base_station_locs[b_ind] - pos[:, s_ind]
            #         )

        # y_meas = np.linalg.norm(self.base_station_locs - pos, axis=1)
        # assert y_meas.shape == (self.num_stations,)

        return y_meas

    def g_jac(self, mu):
        """
        Jacobian of the Measurement Function
        """
        pos = mu[:2]

        # Calculate the Jacobian
        delta_pose = self.base_station_locs - pos
        y_jac = (-delta_pose) / np.linalg.norm(delta_pose, axis=1)[:, None]
        assert y_jac.shape == (self.num_stations, 2)

        # Expand to the full state space (i.e., include the theta dimension)
        y_jac = np.hstack((y_jac, np.zeros((self.num_stations, 1))))
        assert y_jac.shape == (self.num_stations, 3)

        return y_jac

    def sample_f(self, mu, u, n_samples=1):
        """
        Sample the State Transition Model (i.e., with process noise)
        """
        state_noiseless = self.f_func(mu, u)

        # Sample the process noise
        process_noise = np.random.multivariate_normal(
            np.zeros(3), self.q_mat, n_samples).T

        assert process_noise.shape == (mu.shape[0], n_samples)

        return state_noiseless + process_noise

    # def sample_g(self, mu, n_samples=1):
    #     """
    #     Sample the Measurement Model (i.e., with measurement noise)
    #     """
    #     meas_noiseless = self.g_func(mu)

    #     # Sample the measurement noise
    #     out_size = (n_samples, self.num_stations)
    #     meas_noise = np.random.multivariate_normal(
    #         np.zeros(self.num_stations), self.r_mat, out_size)

    #     assert meas_noise.shape == (n_samples, self.num_stations)

    #     return meas_noiseless + meas_noise

    def measurement_likelihood(self, y, x_queries):
        """
        Calculate the measurement likelihood weighted by the measurement noise
        """
        n_queries = x_queries.shape[1]
        n_meas = y.shape[0]

        # Verify the shapes of y in contrast to Rinv
        assert self.r_mat_inv.shape[0] == n_meas

        # Compute the expected measurement for each query
        y_pred = self.g_func(x_queries)
        assert y_pred.shape[0] == n_meas

        # Get the difference up front (akin to centering)
        y_diff = y - y_pred.T
        assert y_diff.shape == (n_queries, n_meas)

        # Calculate the likelihood per measurement
        # Each likelihood is a scalar probability given by
        # exp(-0.5 * y_diff.T @ R_inv @ y_diff) for y_diff in (2, 1)
        # We can vectorize looking at the full calculation in the internal 
        # part of y_diff.T @ R_inv @ y_diff:
        # [y1, y2] [R_inv_11, R_inv_12] [y1]
        #          [R_inv_12, R_inv_22] [y2]
        # = y1^2 * R_inv_11 + 2 * y1 * y2 * R_inv_12 + y2^2 * R_inv_22
        # Is the same as
        # y1 * (y1 * R_inv_11) + y1 * (y2 * R_inv_12) + 
        # y2 * (y1 * R_inv_12) + y2 * (y2 * R_inv_22)

        likelihoods_internal = np.sum(y_diff @ self.r_mat_inv * y_diff, axis=1)
        assert likelihoods_internal.shape == (n_queries,)
        likelihoods = np.exp(-0.5 * likelihoods_internal)

        # Incorrect since it forms a NxN matrix rather than a vector
        # likelihoods = np.exp(
        #     -0.5 * y_diff @ self.r_mat_inv @ y_diff.T
        # )
        assert likelihoods.shape == (n_queries,)

        return likelihoods
