###############
# Script to work with the simulator for the mobile robot system in
# HW4 Question 4.
###############

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import time

import HW4_q4_simulator as sim
import HW4_q4_system_dynamics as sys_dyn
import HW4_q4_filter_base as filtering
import HW4_q4_plot_filters as filter_plot

# File path to save the plots
top_file_path = "HW4_soln_figures/q4_sol_"
dpi_save = 300
bbi = "tight"
show_plots = True

# Define the parameters
n_steps = 100
pose0 = [0, 0, 0]
sigma0 = 0.1 * np.identity(3)
n_pf_samples = 1000
show_plots = False

# Initialize the simulator
# Arguments:
# q_mat: np.array - process noise covariance matrix
# r_mat: np.array - measurement noise covariance matrix
# dt: float - time step
# base_station_locs: np.array - locations of the base stations
# rng_seed: int - for reproducibility
# robot = sim.MobileRobotSimulator(
#     r_mat = 0.1 * np.identity(5),
#     base_station_locs=[
#         [10, 30],
#         [60, 20],
#         [100, -25],
#         [23,-24],
#         [-5,-7]
#     ]
# )

robot = sim.MobileRobotSimulator()

# Run a single simulation
pose_hist, y_hist, u_hist = robot.simulate(pose0, n_steps) #, rng_seed=100)

# We offer very similar plotting functions to visualize the results as in the
# quadrotor simulator:
# 1. robot.plot_position_history(...) - plots the 2D position over time
# 2. robot.plot_pose_history(...) - plots the 2D pose over time [a bit slower]
# 3. robot.plot_control_history(...) - plots each control input against time
# 4. robot.plot_measurement_history(...) - plots each measurement against time
# 5. robot.plot_2D_errors(...) - plots the 2D errors for covariance analysis

# If you want to run multiple simulations, you can use the
# simulate_multiple_runs method (i.e., robot.simulate_multiple_runs(...))
# Arguments:
# pose0: np.array - initial pose
# n_steps: int - number of steps to simulate
# n_sims: int - number of simulations to run
#
# Returns:
# pose_run_hists: np.array - pose history for each run
# y_run_hists: np.array - measurement history for each run
# u_run_hists: np.array - control history for each run

# We, again, offer similar plotting functions to visualize the results:
# 1. robot.plot_position_histories(...) - plots the 2D positions across runs
# 2. robot.plot_measurement_histories(...) - plots the measurements across runs

# %% Interfacing with your EKF, UKF, or particle filter

# As in the quadrotor simulator, you can either generate the _whole_ simulation
# data and then pass it to your filter, or you can run the filter and simulator
# in lockstep. The latter is more realistic, but the former is even more
# convient in this case than the previous case becuase you need to make sure
# That the EKF, UKF, and PF are operating on the _same_ run!

# If you are using the first method, you will use robot.simulate(...)
# But, since u_hist_to_replace and y_hist_to_replace are defined at the start
# and fixed, you can run each filter in a separate for loop, if you want.

# Observability Analysis Initialization
obs_svd_hist = np.zeros((n_steps+1, 3))
obs_timing_hist = np.ones(n_steps)

# EKF History Initialization
x_est_ekf_hist = np.zeros((n_steps+1, 3))
p_est_ekf_hist = np.zeros((n_steps+1, 3, 3))
ekf_timing_hist = np.ones(n_steps)

x_est_ekf_hist[0, :] = pose0
p_est_ekf_hist[0, :, :] = sigma0

# UKF History Initialization
x_est_ukf_hist = np.zeros((n_steps+1, 3))
p_est_ukf_hist = np.zeros((n_steps+1, 3, 3))
ukf_timing_hist = np.ones(n_steps)

x_est_ukf_hist[0, :] = pose0
p_est_ukf_hist[0, :, :] = sigma0

# PF History Initialization
x_est_pf_hist = np.zeros((n_steps+1, 3))
p_est_pf_hist = np.zeros((n_steps+1, 3, 3))
particle_est_pf_hist = np.zeros((n_steps+1, 3, n_pf_samples))
weights_pf_hist = np.zeros((n_steps+1, n_pf_samples))
pf_timing_hist = np.ones(n_steps)

x_est_pf_hist[0, :] = pose0
p_est_pf_hist[0, :, :] = sigma0

# Instantiate the dynamics
robot_model = sys_dyn.MobileRobot(robot.q_mat, robot.r_mat, robot.dt,
                                  robot.base_station_locs)

robot_ekf = filtering.EKFBase(robot_model, pose0, sigma0)
robot_ukf = filtering.UKFBase(robot_model, pose0, sigma0,
                              sqrt_method='cholesky')
robot_pf = filtering.PFBase(robot_model, pose0, sigma0,
                            n_particles=n_pf_samples)

# Add the initial particles from the PF to the history
particle_est_pf_hist[0, :, :] = robot_pf.particles
weights_pf_hist[0, :] = robot_pf.weights

# Run the filters together
for t_index, (u, y) in enumerate(zip(u_hist, y_hist)):

    obs_start_time = time.perf_counter_ns()
    # Check the observability (through SVD) with the system dynamics
    # We use the most recent EKF state to align with the question,
    # but you could extend the analysis (e.g., using the true state).
    svd_vals = robot_model.observability_svd_vals(
        x_est_ekf_hist[t_index], u_hist[t_index])
    # svd_vals = robot_model.observability_svd_vals(
    #     pose_hist[t_index], u_hist[t_index])
    obs_svd_hist[t_index, :] = svd_vals
    obs_timing_hist[t_index] = time.perf_counter_ns() - obs_start_time

    # Use (u, y) to step your filter
    # For example:
    # x_est_ekf, P_est_ekf = ekf.step(u, y)
    # x_est_ukf, P_est_ukf = ukf.step(u, y)
    # x_est_samples_pf, weights_pf = pf.step(u, y)

    # EKF
    ekf_start_time = time.perf_counter_ns()
    # print("Start time", ekf_start_time)
    x_est_ekf, p_est_ekf = robot_ekf.step(u, y)

    x_est_ekf_hist[t_index+1, :] = x_est_ekf
    p_est_ekf_hist[t_index+1, :, :] = p_est_ekf
    ekf_timing_hist[t_index] = time.perf_counter_ns() - ekf_start_time

    # UKF
    ukf_start_time = time.perf_counter_ns()
    x_est_ukf, p_est_ukf = robot_ukf.step(u, y)

    x_est_ukf_hist[t_index+1, :] = x_est_ukf
    p_est_ukf_hist[t_index+1, :, :] = p_est_ukf
    ukf_timing_hist[t_index] = time.perf_counter_ns() - ukf_start_time

    # PF
    pf_start_time = time.perf_counter_ns()
    x_est_pf, p_est_pf, particle_est_pf, weights_pf = robot_pf.step(u, y)

    x_est_pf_hist[t_index+1, :] = x_est_pf
    p_est_pf_hist[t_index+1, :, :] = p_est_pf
    particle_est_pf_hist[t_index+1, :, :] = particle_est_pf
    weights_pf_hist[t_index+1, :] = weights_pf
    pf_timing_hist[t_index] = time.perf_counter_ns() - pf_start_time

# Run an additional observability analysis at the end
svd_vals = robot_model.observability_svd_vals(
    x_est_ekf_hist[-1], u_hist[-1])
obs_svd_hist[-1, :] = svd_vals

#################################
# Plot the results
# EKF ONLY
fig = robot.plot_pose_history(pose_hist, show_plot=False)
filter_plot.plot_filter_trajectory(
    # x_est_ekf_hist[:, :2], p_est_ekf_hist[:, :2, :2],
    x_est_ekf_hist, p_est_ekf_hist,
    0.95, "g", fig.gca(), "EKF")
plt.legend()
if show_plots:
    plt.show()
fig.savefig(top_file_path + "ekf_pose_history.png",
            dpi=dpi_save, bbox_inches=bbi)

# OBSERVABILITY WITH EKF
fig = robot.plot_pose_history(pose_hist, show_plot=False)
plt.scatter(
    x_est_ekf_hist[:, 0], x_est_ekf_hist[:, 1],
    label="EKF Position Estimate with Third Singular Value",
    c=obs_svd_hist[:, 2],
    cmap="viridis",
    norm=matplotlib.colors.LogNorm(
        vmin=min(1e-3, obs_svd_hist[:, 2].min()),
        vmax=max(1, obs_svd_hist[:, 2].max())),
    zorder=3
)
plt.colorbar(label="Third Singular Value of Observability Matrix")
plt.xlabel("x (m)")
plt.ylabel("y (m)")
plt.title("Observability Analysis with EKF")
plt.legend()
if show_plots:
    plt.show()
fig.savefig(top_file_path + "observability_ekf.png",
            dpi=dpi_save, bbox_inches=bbi)

# UKF ONLY
fig = robot.plot_pose_history(pose_hist, show_plot=False)
filter_plot.plot_filter_trajectory(
    # x_est_ukf_hist[:, :2], p_est_ukf_hist[:, :2, :2],
    x_est_ukf_hist, p_est_ukf_hist,
    0.95, "g", fig.gca(), "UKF")
plt.legend()
if show_plots:
    plt.show()
fig.savefig(top_file_path + "ukf_pose_history.png",
            dpi=dpi_save, bbox_inches=bbi)

# PF ONLY
fig = robot.plot_pose_history(pose_hist, show_plot=False)
filter_plot.plot_filter_trajectory(
    # x_est_pf_hist[:, :2], p_est_pf_hist[:, :2, :2],
    x_est_pf_hist, p_est_pf_hist,
    0.95, "g", fig.gca(), "PF")
plt.legend()
if show_plots:
    plt.show()
fig.savefig(top_file_path + "pf_pose_history_ellipses.png",
            dpi=dpi_save, bbox_inches=bbi)

fig = robot.plot_pose_history(pose_hist, show_plot=False)
filter_plot.plot_particle_filter_trajectory(
    particle_est_pf_hist, "g", fig.gca(), "PF")
plt.legend()
if show_plots:
    plt.show()
fig.savefig(top_file_path + "pf_pose_history_particles.png",
            dpi=dpi_save, bbox_inches=bbi)

#################################
# Over time
# Observability
fig, ax = plt.subplots(1, 1, figsize=(6, 4))
ax.semilogy(obs_svd_hist[:, 0], label="Singular Value 1")
ax.semilogy(obs_svd_hist[:, 1], label="Singular Value 2")
ax.semilogy(obs_svd_hist[:, 2], label="Singular Value 3")
ax.set_xlabel("Time Step")
ax.set_ylabel("Singular Value")
ax.set_title("Observability Analysis")
ax.legend()
if show_plots:
    plt.show()
fig.savefig(top_file_path + "observability_analysis.png",
            dpi=dpi_save, bbox_inches=bbi)

# EKF ONLY
fig, _ = filter_plot.plot_filter_time_history(
    pose_hist, x_est_ekf_hist, p_est_ekf_hist, 0.95, "EKF"
)
fig.savefig(top_file_path + "ekf_time_history.png",
            dpi=dpi_save, bbox_inches=bbi)

# UKF ONLY
fig, _ = filter_plot.plot_filter_time_history(
    pose_hist, x_est_ukf_hist, p_est_ukf_hist, 0.95, "UKF"
)
fig.savefig(top_file_path + "ukf_time_history.png",
            dpi=dpi_save, bbox_inches=bbi)

# PF ONLY
for pf_plot_type in ['violin', 'scatter', 'boxplot']:
    print(f"Plotting PF as {pf_plot_type}...")
    fig, _ = filter_plot.plot_particle_filter_distribution_history(
        pose_hist, particle_est_pf_hist, "PF", plot_type=pf_plot_type
    )
    fig.savefig(top_file_path + f"pf_time_history_{pf_plot_type}.png",
                dpi=dpi_save, bbox_inches=bbi)


#################################
# Over time as an ERROR
ref_pose_zeros = np.zeros_like(pose_hist)

# EKF ONLY
x_est_ekf_hist_err = x_est_ekf_hist[:-1] - pose_hist
assert x_est_ekf_hist_err.shape == ref_pose_zeros.shape
fig, _ = filter_plot.plot_filter_time_history(
    ref_pose_zeros, x_est_ekf_hist_err, p_est_ekf_hist[:-1], 0.95, "EKF",
    is_error=True
)
fig.savefig(top_file_path + "ekf_time_history_error.png",
            dpi=dpi_save, bbox_inches=bbi)

# UKF ONLY
x_est_ukf_hist_err = x_est_ukf_hist[:-1] - pose_hist
assert x_est_ukf_hist_err.shape == ref_pose_zeros.shape
fig, _ = filter_plot.plot_filter_time_history(
    ref_pose_zeros, x_est_ukf_hist_err, p_est_ukf_hist[:-1], 0.95, "UKF",
    is_error=True
)
fig.savefig(top_file_path + "ukf_time_history_error.png",
            dpi=dpi_save, bbox_inches=bbi)

# PF ONLY
particle_est_pf_hist_err = particle_est_pf_hist[:-1] - \
                            pose_hist[:, :, np.newaxis]

for pf_plot_type in ['violin', 'scatter', 'boxplot']:
    print(f"Plotting PF as {pf_plot_type}...")
    fig, _ = filter_plot.plot_particle_filter_distribution_history(
        ref_pose_zeros, particle_est_pf_hist_err, "PF", plot_type=pf_plot_type,
        is_error=True
    )
    fig.savefig(top_file_path + f"pf_time_history_{pf_plot_type}_error.png",
                dpi=dpi_save, bbox_inches=bbi)

#################################
# Timing Analysis
# (Boxplot)
# NS_TO_S = 1e-9
NS_TO_US = 1e-3
time_units = "$\mu$s"
timing_hists = [obs_timing_hist,
                ekf_timing_hist,
                ukf_timing_hist,
                pf_timing_hist]
timing_hists = [timing_hist * NS_TO_US for timing_hist in timing_hists]

fig, ax = plt.subplots(1, 1, figsize=(6, 4))
ax.boxplot(timing_hists,
           tick_labels=["Observability", "EKF", "UKF", "PF"])
ax.set_ylabel(f"Time ({time_units})")
fig.savefig(top_file_path + "timing_analysis.png",
            dpi=dpi_save, bbox_inches=bbi)

# (Violin)
fig, ax = plt.subplots(1, 1, figsize=(6, 4))
ax.violinplot(timing_hists)
ax.set_xticks(np.arange(len(timing_hists)) + 1)
ax.set_xticklabels(["Observability", "EKF", "UKF", "PF"])
ax.set_ylabel(f"Time ({time_units})")
fig.savefig(top_file_path + "timing_analysis_violin.png",
            dpi=dpi_save, bbox_inches=bbi)

# Histogram
fig, ax = plt.subplots(1, 1, figsize=(6, 4))
ax.hist(timing_hists,
        bins=50, label=["Observability", "EKF", "UKF", "PF"],
        histtype='step', stacked=False, fill=False)
ax.set_xlabel(f"Time ({time_units})")
ax.set_ylabel("Frequency")
ax.legend()
fig.savefig(top_file_path + "timing_analysis_hist.png",
            dpi=dpi_save, bbox_inches=bbi)
