###########################
# Simulate the Filters
###########################

import numpy as np
import scipy.linalg

import HW4_q4_system_dynamics as sys_dyn


class EKFBase:
    """
    Base class for the Extended Kalman Filter
    """
    def __init__(self, system: sys_dyn.DynamicSystem,
                 mu0=None, sigma0=None):
        """
        Initialize the EKF with the system matrices
        """
        self.system = system

        self.mu = np.array(mu0)
        self.sigma = np.array(sigma0)

    def predict(self, u=None):
        """
        EKF Predict Step
        """

        # Predict the next state (t|t-1) from the current state (t-1|t-1)
        self.mu = self.system.f_func(self.mu, u)

        # Predict the next covariance
        a_mat = self.system.f_jac(self.mu, u)
        self.sigma = a_mat @ self.sigma @ a_mat.T + self.system.q_mat

        return self.mu, self.sigma

    def update(self, y):
        """
        EKF Update Step
        """
        # Calculate the Kalman Gain
        c_mat = self.system.g_jac(self.mu)
        s_mat = c_mat @ self.sigma @ c_mat.T + self.system.r_mat
        k_mat = self.sigma @ c_mat.T @ np.linalg.inv(s_mat)

        # Update the state estimate (t|t) from the predicted state (t|t-1)
        self.mu += k_mat @ (y - self.system.g_func(self.mu))
        # Update the covariance
        self.sigma = (np.eye(self.sigma.shape[0]) - k_mat @ c_mat) @ self.sigma

        return self.mu, self.sigma

    def step(self, u, y):
        """
        EKF Step
        """
        self.predict(u)
        self.update(y)

        return self.mu, self.sigma

class UKFBase:
    """
    Base class for the Unscented (sigma-point) Kalman Filter
    """
    def __init__(self, system: sys_dyn.DynamicSystem,
                 mu0=None, sigma0=None,
                 sqrt_method='scipy', ukf_lambda=2,
                 psd_eig_tol=1e-11):
        """
        Initialize the UKF with the system matrices
        """
        self.system = system

        self.mu = np.array(mu0)
        self.sigma = np.array(sigma0)

        # Initialize the weights (will be the same for all UKF instances)
        self.n = len(mu0)
        self.ukf_lambda = ukf_lambda
        self.weights = self.initialize_weights()
        self.sqrt_method = sqrt_method
        self.psd_eig_tol = psd_eig_tol

        self.test_ut()

    def mat_sqrt(self, mat):
        """
        Compute the matrix square root given the specified method in
        the constructor.
        """
        if self.sqrt_method == 'scipy':
            sqrt_mat_out = scipy.linalg.sqrtm(mat)
        elif self.sqrt_method == 'eig':
            eig_val, eig_vec = np.linalg.eig(mat)
            # Handle numerical issues with the eigenvalues (e.g. negative,
            # near-zero, or complex values)
            eig_val = np.real(eig_val)
            eig_val = np.maximum(eig_val, self.psd_eig_tol)
            eig_vec = np.real(eig_vec)
            sqrt_mat_out = eig_vec @ np.diag(np.sqrt(eig_val)) @ eig_vec.T
        elif self.sqrt_method == 'cholesky':
            sqrt_mat_out = np.linalg.cholesky(mat)
        else:
            raise ValueError("Invalid sqrt method")

        # Check the fidelity of the square root
        assert np.allclose(sqrt_mat_out @ sqrt_mat_out.T, mat)

        return sqrt_mat_out

    def initialize_weights(self):
        """
        Initialize the weights for the UKF, lambda is a scaling parameter, which
        is usually set to 2. Note that there are other ways to initialize the
        weights, but this is the one from class.
        """
        weights = np.zeros(2*self.n+1)
        weights[0] = self.ukf_lambda / (self.n + self.ukf_lambda)
        weights[1:] = 1 / (2*(self.n + self.ukf_lambda))

        assert np.isclose(weights.sum(), 1), "Weights do not sum to 1"
        assert np.inf not in weights, "Weights are infinite"

        return weights

    def unscented_transform(self, mu, sigma):
        """
        Unscented Transform
        """
        # Compute the matrix square root of the covariance
        # sigma = self.force_psd_sym_covariance(sigma)
        covar_mat_sqrt = self.mat_sqrt(sigma)

        if np.any(np.iscomplex(covar_mat_sqrt)):
            raise ValueError(f"Covariance PSD is not holding: {covar_mat_sqrt}")

        # Initialize the sigma points
        x_sp = mu[:, np.newaxis] * np.ones((self.n, 2*self.n+1))

        # The first sigma point is the mean and already initialized.
        # The rest of the sigma points
        sqrt_term = np.sqrt(self.n + self.ukf_lambda) * covar_mat_sqrt

        # Non-vectorized option
        # for sp_ind in range(self.n):
        #     # print(sp_ind)
        #     x_sp[:, sp_ind+1] = mu + sqrt_term[:, sp_ind]
        #     x_sp[:, self.n + sp_ind + 1] = mu - sqrt_term[:, sp_ind]

        mu_rep = mu[:, np.newaxis]
        x_sp[:, 1:(self.n + 1)] = mu_rep + sqrt_term
        x_sp[:, (self.n + 1):] = mu_rep - sqrt_term

        return x_sp

    def inverse_unscented_transform(self, x_sp):
        """
        Inverse Unscented Transform
        """
        # Compute the mean and covariance from the sigma points
        mu = x_sp @ self.weights

        diff = x_sp - mu[:, np.newaxis]
        assert diff.shape[1] == 2*self.n+1

        # Non-vectorized option
        # sigma = np.zeros((mu.shape[0], mu.shape[0]))
        # for sp_ind, wi in enumerate(self.weights):
        #     sigma += wi * np.outer(diff[:, sp_ind], diff[:, sp_ind])

        # Vectorized option
        sigma = diff @ np.diag(self.weights) @ diff.T

        # Important: Do not set to self or add noise here!

        return mu, sigma

    def test_ut(self):
        """
        Test the Unscented Transform
        """
        # Check that the weights are still intact
        assert np.isclose(self.weights.sum(), 1), "Weights do not sum to 1"
        assert np.inf not in self.weights, "Weights are infinite"
        assert len(self.weights) == 2 * self.n + 1

        # Test the Unscented Transform
        x_sp = self.unscented_transform(self.mu, self.sigma)
        assert x_sp.shape == (self.n, 2*self.n+1)

        # Test the Inverse Unscented Transform
        mu, sigma = self.inverse_unscented_transform(x_sp)
        assert mu.shape == (self.n,)
        assert sigma.shape == (self.n, self.n)

        # Check that the values are the same
        assert np.allclose(mu, self.mu), \
            f"\ncalculated mu: {mu}\n   current mu: {self.mu}"
        assert np.allclose(sigma, self.sigma), \
            f"\ncalculated sigma: {sigma}\n   current sigma: {self.sigma}"

    def force_psd_sym_covariance(self, mat):
        """
        Force a covariance matrix to be positive semi-definite and symmetric
        """
        # Symmetrize the matrix
        mat = (mat + mat.T) / 2

        # Force the matrix to be positive semi-definite
        eig_val, eig_vec = np.linalg.eig(mat)
        eig_val = np.real(eig_val)
        eig_val = np.maximum(eig_val, self.psd_eig_tol)

        eig_vec = np.real(eig_vec)

        mat_out = eig_vec @ np.diag(eig_val) @ eig_vec.T

        if np.any(np.iscomplex(mat_out)):
            raise ValueError(f"Covariance PSD is not holding: {mat_out}")

        return mat_out

    def predict(self, u=None):
        """
        UKF Predict Step
        """
        # Unscented Transform
        x_sp = self.unscented_transform(self.mu, self.sigma)

        # Propagate the sigma points through the state transition function
        x_sp_next = self.system.f_func(x_sp, u)
        assert x_sp_next.shape == x_sp.shape

        # Compute the predicted mean and covariance
        self.mu, self.sigma = self.inverse_unscented_transform(x_sp_next)

        # Add the process noise
        self.sigma += self.system.q_mat

        return self.mu, self.sigma

    def update(self, y):
        """
        UKF Update Step
        """
        # Unscented Transform
        x_sp = self.unscented_transform(self.mu, self.sigma)

        # Propagate the sigma points through the measurement function
        y_sp = self.system.g_func(x_sp)
        assert y_sp.shape[0] == len(y)

        # Compute the expected measurement and empirical covariance
        y_mu, y_sigma = self.inverse_unscented_transform(y_sp)

        # Add the measurement noise
        y_sigma += self.system.r_mat

        # Compute the cross-covariance
        diff_x = x_sp - self.mu[:, np.newaxis]
        diff_y = y_sp - y_mu[:, np.newaxis]
        assert diff_x.shape[1] == diff_y.shape[1]
        assert diff_x.shape[1] == len(self.weights)

        sigma_xy = diff_x @ np.diag(self.weights) @ diff_y.T
        assert sigma_xy.shape == (self.n, len(y))

        # Use the Gaussian Estimation equations (this is akin to the
        # Kalman Gain computation)
        y_sigma_inv = np.linalg.inv(y_sigma)
        self.mu += sigma_xy @ y_sigma_inv @ (y - y_mu)
        self.sigma -= sigma_xy @ y_sigma_inv @ sigma_xy.T

        # Force the covariance to be positive semi-definite and symmetric
        # self.sigma = self.force_psd_sym_covariance(self.sigma)

        return self.mu, self.sigma

    def step(self, u, y):
        """
        UKF Step
        """
        self.predict(u)
        self.update(y)

        # self.test_ut()

        return self.mu, self.sigma


class PFBase:
    """
    Base class for the Particle Filter
    """
    def __init__(self, system: sys_dyn.DynamicSystem,
                 mu0=None, sigma0=None, resample_method='importance_resample',
                 n_particles=1000):
        """
        Initialize the PF with the system matrices
        """
        self.system = system

        self.mu = np.array(mu0)
        self.sigma = np.array(sigma0)

        self.n_particles = n_particles

        self.particles = None
        self.weights = None
        self.initialize_particles()

        self.eps = 2 * np.finfo(float).eps

        self.resample_method = resample_method

    def initialize_particles(self):
        """
        Initialize the particles
        """
        self.particles = np.random.multivariate_normal(self.mu, self.sigma,
                                                       size=self.n_particles).T
        # We choose (n_dim, n_particles) for the shape of the particles
        # Since the mu terms have (n_dim,) shape and we want to respect
        # the order of the axes
        assert self.particles.shape == (self.mu.shape[0], self.n_particles)
        
        self.weights = np.ones(self.n_particles) / self.n_particles
        assert self.weights.shape == (self.n_particles,)
        assert np.isclose(self.weights.sum(), 1), "Weights do not sum to 1"

    def predict(self, u=None):
        """
        PF Predict Step
        """
        # Propagate the particles through the state transition function
        self.particles = self.system.sample_f(self.particles, u, 
                                              n_samples=self.n_particles)
        
        assert self.particles.shape == (self.mu.shape[0], self.n_particles)

        return self.particles
    
    def update(self, y):
        """
        PF Update Step
        """
        # Compute the likelihood of the particles
        likelihoods = self.system.measurement_likelihood(y, self.particles)

        # Update the weights
        self.weights = likelihoods / (likelihoods.sum() + self.eps)
        assert self.weights.shape == (self.n_particles,)
        assert np.isclose(self.weights.sum(), 1), "Weights do not sum to 1"

        return self.weights
    
    def resample(self):
        """
        PF Resample Step
        """
        if self.resample_method == 'importance_resample':
            # Resample the particles
            indices = np.random.choice(np.arange(self.n_particles),
                                       size=self.n_particles,
                                       p=self.weights)

            self.particles = self.particles[:, indices]
            self.weights = np.ones(self.n_particles) / self.n_particles
        else:
            raise NotImplementedError("Requested resample method not supported")

        return self.particles, self.weights
    
    def get_curr_mu_sigma(self):
        """
        Get the current mean and covariance
        """
        mu = np.average(self.particles, axis=1, weights=self.weights)
        assert mu.shape == self.mu.shape
        sigma = np.cov(self.particles, aweights=self.weights)
        assert sigma.shape == self.sigma.shape

        return mu, sigma
    
    def step(self, u, y):
        """
        PF Step
        """
        self.predict(u)
        self.update(y)
        self.resample()

        self.mu, self.sigma = self.get_curr_mu_sigma()

        return self.mu, self.sigma, self.particles, self.weights
