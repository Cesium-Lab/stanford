
import HW4_q4_simulator as sim
# import numpy as np

# File path to save the plots
top_file_path = "HW4_soln_figures/"
dpi_save = 300
bbi = "tight"
show_plots = False

# Define the parameters
n_steps = 100
pose0 = [0, 0, 0]

# Initialize the simulator
# robot = sim.MobileRobotSimulator(
#     r_mat=0.1 * np.identity(3),
#     base_station_locs=np.array([[30, -5], [-10, 20], [-25, -15]]),
# )
robot = sim.MobileRobotSimulator()

# Run the simulation
pose_hist, y_hist, u_hist = robot.simulate(pose0, n_steps)

# Plot the results
fig = robot.plot_pose_history(pose_hist, show_plot=show_plots)
fig.savefig(top_file_path + "pose_history.png", dpi=dpi_save, bbox_inches=bbi)
fig = robot.plot_control_history(u_hist, show_plot=show_plots)
fig.savefig(top_file_path + "control_history.png",
            dpi=dpi_save, bbox_inches=bbi)
fig = robot.plot_measurement_history(y_hist, show_plot=show_plots)
fig.savefig(top_file_path + "measurement_history.png",
            dpi=dpi_save, bbox_inches=bbi)

# Run many simulations
n_sims = 10
pose_run_hists, y_run_hists, u_run_hists = \
    robot.simulate_multiple_runs(pose0, n_steps, n_sims)

# Plot the results
fig = robot.plot_position_histories(pose_run_hists, show_plot=show_plots)
fig.savefig(top_file_path + "position_histories.png",
            dpi=dpi_save, bbox_inches=bbi)
fig = robot.plot_measurement_histories(y_run_hists, show_plot=show_plots)
fig.savefig(top_file_path + "measurement_histories.png",
            dpi=dpi_save, bbox_inches=bbi)
