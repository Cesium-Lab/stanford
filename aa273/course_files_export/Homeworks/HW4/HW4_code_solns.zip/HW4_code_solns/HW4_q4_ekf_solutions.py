###########################
# Simulate the EKF
###########################

import numpy as np
import matplotlib.pyplot as plt
import scipy.stats

from HW4_q4_plot_filters import plot_ellipse_updated

class EKFBase:
    """
    Base class for the Extended Kalman Filter
    """
    def __init__(self, q_mat, r_mat,
                 mu0=None, sigma0=None):
        """
        Initialize the EKF with the system matrices
        """
        self.q_mat = np.array(q_mat)
        self.r_mat = np.array(r_mat)

        self.mu = mu0
        self.sigma = sigma0

    def f_func(self, mu, u):
        """
        State Transition Function
        """
        raise NotImplementedError

    def f_jac(self, mu, u):
        """
        Jacobian of the State Transition Function
        """
        raise NotImplementedError

    def g_func(self, mu):
        """
        Measurement Function
        """
        raise NotImplementedError

    def g_jac(self, mu):
        """
        Jacobian of the Measurement Function
        """
        raise NotImplementedError

    def predict(self, u=None):
        """
        EKF Predict Step
        """

        # Predict the next state (t|t-1) from the current state (t-1|t-1)
        self.mu = self.f_func(self.mu, u)

        # Predict the next covariance
        a_mat = self.f_jac(self.mu, u)
        self.sigma = a_mat @ self.sigma @ a_mat.T + self.q_mat

        return self.mu, self.sigma

    def update(self, y):
        """
        EKF Update Step
        """
        # Calculate the Kalman Gain
        c_mat = self.g_jac(self.mu)
        s_mat = c_mat @ self.sigma @ c_mat.T + self.r_mat
        k_mat = self.sigma @ c_mat.T @ np.linalg.inv(s_mat)

        # Update the state estimate (t|t) from the predicted state (t|t-1)
        self.mu += k_mat @ (y - self.g_func(self.mu))
        # Update the covariance
        self.sigma = (np.eye(self.sigma.shape[0]) - k_mat @ c_mat) @ self.sigma

        return self.mu, self.sigma

    def step(self, u, y):
        """
        EKF Step
        """
        self.predict(u)
        self.update(y)

        return self.mu, self.sigma


class MobileRobotEKF(EKFBase):
    """
    Child class for the Mobile Robot EKF
    """
    def __init__(self, q_mat, r_mat, dt, base_station_locs,
                 mu0=None, sigma0=None):
        """
        Initialize the EKF with the system matrices
        """
        super().__init__(q_mat, r_mat, mu0, sigma0)
        self.dt = dt
        self.base_station_locs = np.array(base_station_locs)
        self.num_stations = base_station_locs.shape[0]

    def f_func(self, mu, u):
        """
        State Transition Function
        """
        px, py, theta = mu
        s, phi = u

        px_new = px + self.dt * s * np.cos(theta)
        py_new = py + self.dt * s * np.sin(theta)
        theta_new = theta + self.dt * phi

        return np.array([px_new, py_new, theta_new])

    def f_jac(self, mu, u):
        """
        Jacobian of the State Transition Function
        """
        _, _, theta = mu
        s, _ = u

        return np.array([
            [1, 0, -self.dt * s * np.sin(theta)],
            [0, 1, self.dt * s * np.cos(theta)],
            [0, 0, 1]
        ])

    def g_func(self, mu):
        """
        Measurement Function
        """
        pos = mu[:2]

        y_meas = np.linalg.norm(self.base_station_locs - pos, axis=1)
        assert y_meas.shape == (self.num_stations,)

        return y_meas

    def g_jac(self, mu):
        """
        Jacobian of the Measurement Function
        """
        pos = mu[:2]

        # Calculate the Jacobian
        delta_pose = self.base_station_locs - pos
        y_jac = (-delta_pose) / np.linalg.norm(delta_pose, axis=1)[:, None]
        assert y_jac.shape == (self.num_stations, 2)

        # Expand to the full state space (i.e., include the theta dimension)
        y_jac = np.hstack((y_jac, np.zeros((self.num_stations, 1))))
        assert y_jac.shape == (self.num_stations, 3)

        return y_jac

def plot_ekf_trajectory(mu, sigma, p_conf, color, ax):
    """
    Plot the trajectory of the EKF
    :param mu: The mean
    :param sigma: The covariance matrix
    :param p_conf: The probability
    :param color: The ellipse color
    :param ax: The axes
    :return: None
    """
    # Plot the ellipse
    for mu_t, sigma_t in zip(mu, sigma):
        plot_ellipse_updated(mu_t, sigma_t, p_conf, color, ax)

    # Plot the trajectory
    ax.plot(mu[:, 0], mu[:, 1], color=color, marker='x',
            linestyle='--', markersize=5, zorder=3, label='EKF Estimate')


def plot_1D_confidence_interval(mu, sigma, p_conf, color, ax):
    """
    Plot the 1D confidence interval
    :param mu: The mean
    :param sigma: The covariance matrix
    :param p_conf: The probability
    :param color: The ellipse color
    :param ax: The axes
    :return: None
    """
    # Get z-score for the (centered) confidence interval
    # scipy will give the z-score for the lower tail, so we need to
    # split the difference such that (1 - p_conf)/2 is in each tail.
    # 1 - (1 - p_conf)/2 = 1/2 + p_conf/2
    p_query = 1/2 + p_conf/2
    z_score = scipy.stats.norm.ppf(p_query)
    print(f"Z-Score: {z_score} at {p_conf} confidence")

    # Plot the 1D confidence interval
    std_t = np.sqrt(sigma)
    covar_above = mu + z_score * std_t
    covar_below = mu - z_score * std_t
    t_stamps = np.arange(len(mu))
    ax.fill_between(t_stamps, covar_below, covar_above,
                        color=color, alpha=0.2, zorder=2)

    # Plot the mean
    ax.plot(t_stamps, mu, color=color, linestyle='--', zorder=3)


def plot_ekf_trajectory_history(true_pose, ekf_pose, ekf_sigma, p_conf):
    """
    Plot the trajectory of the EKF as a function of time
    :param true_pose: The true pose
    :param ekf_pose: The EKF pose
    :param ekf_sigma: The EKF sigma
    :param p_conf: The probability
    :return: None
    """
    # Plot the trajectory
    fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(15, 5))

    # Plot the each
    labels = ['X Position', 'Y Position', 'Theta Heading']
    for ax_idx, (ax, label) in enumerate(zip(axes, labels)):
        ax.plot(true_pose[:, ax_idx], color='b')
        plot_1D_confidence_interval(
            ekf_pose[:, ax_idx], ekf_sigma[:, ax_idx, ax_idx],
            p_conf, 'g', ax)
        ax.set_title(label)
        ax.legend(['True',
                   f'EKF {int(p_conf*100)}% CI',
                   "EKF Estimate"])

    return fig, axes
